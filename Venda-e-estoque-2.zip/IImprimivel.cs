namespace Venda_e_estoque_2
{
    public interface IImprimivel
    {
        void Imprimir();
    }
}